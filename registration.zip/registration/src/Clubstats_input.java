

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Admin_Clubstats")
public class Clubstats_input extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Clubstats_input() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String StatID=request.getParameter("StatID");
		String Statistic=request.getParameter("Statistic");
		String StatType=request.getParameter("StatType");
		String Player=request.getParameter("Player");
		String Season=request.getParameter("Season");
		
		Clubstats clubstats=new Clubstats(StatID,Statistic,StatType,Player,Season);
		Clubstats_input_dao rdao=new Clubstats_input_dao();
		String result=rdao.insert(clubstats);
		response.getWriter().println(result);
		
	}

}
