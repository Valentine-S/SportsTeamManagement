import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Players_input_dao {
	private String dburl = "jdbc:mysql://localhost:3306/demodb";
	private String dbuname = "root";
	private String dbpassword = "";
	private String dbdriver = "com.mysql.jdbc.Driver";

	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dburl, dbuname, dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public String insert(Players players) {
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into Players values(?,?,?,?,?,?,?,?,?)";
		String result="Data Entered Successfully";
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, players.getPlayer_ID());
			ps.setString(2, players.getFirstName());
			ps.setString(3, players.getLastName());
			ps.setNString(4, players.getPlayerPosition());
			ps.setNString(5, players.getDominantHand());
			ps.setNString(6, players.getDOB());
			ps.setNString(7, players.getContactInfo());
			ps.setNString(8, players.getSponsorName());
			ps.setNString(9, players.getPlayerStats());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			result="Players are Not Entered Successfully";
			e.printStackTrace();
		}
		return result;

	}
}
