

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Admin_Player")
public class Players_input extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Players_input() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Player_ID=request.getParameter("Player_ID");
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
		String PlayerPosition=request.getParameter("PlayerPosition");
		String DominantHand=request.getParameter("DominantHand");
		String DOB=request.getParameter("DOB");
		String ContactInfo=request.getParameter("ContactInfo");
		String SponsorName=request.getParameter("SponsorName");
		String PlayerStats=request.getParameter("PlayerStats");
		
		Players players=new Players(Player_ID,FirstName,LastName,PlayerPosition,DominantHand,DOB,ContactInfo,SponsorName,PlayerStats);
		Players_input_dao rdao=new Players_input_dao();
		String result=rdao.insert(players);
		response.getWriter().println(result);
		
	}

}
