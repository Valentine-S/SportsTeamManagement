
public class Clubstats 
{
	private String StatID,Statistic,StatType,Player,Season;

	public Clubstats() {
		super();
	}


	
	public Clubstats(String statID, String statistic, String statType, String player, String season) {
		super();
		StatID = statID;
		Statistic = statistic;
		StatType = statType;
		Player = player;
		Season = season;
	}



	public String getStatID() {
		return StatID;
	}

	public void setStatID(String statID) {
		StatID = statID;
	}

	public String getStatistic() {
		return Statistic;
	}

	public void setStatistic(String statistic) {
		Statistic = statistic;
	}

	public String getStatType() {
		return StatType;
	}

	public void setStatType(String statType) {
		StatType = statType;
	}

	public String getPlayer() {
		return Player;
	}

	public void setPlayer(String player) {
		Player = player;
	}

	public String getSeason() {
		return Season;
	}

	public void setSeason(String season) {
		Season = season;
	}
	
	
	
	

	
}
