
public class Players 
{
	private String Player_ID,FirstName,LastName,PlayerPosition,DominantHand,DOB,ContactInfo,SponsorName,PlayerStats;

	public Players() {
		super();
	}

	public Players(String player_ID, String firstName, String lastName, String playerPosition, String dominantHand,
			String dOB, String contactInfo, String sponsorName, String playerStats) {
		super();
		Player_ID = player_ID;
		FirstName = firstName;
		LastName = lastName;
		PlayerPosition = playerPosition;
		DominantHand = dominantHand;
		DOB = dOB;
		ContactInfo = contactInfo;
		SponsorName = sponsorName;
		PlayerStats = playerStats;
	}

	public String getPlayer_ID() {
		return Player_ID;
	}

	public void setPlayer_ID(String player_ID) {
		Player_ID = player_ID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPlayerPosition() {
		return PlayerPosition;
	}

	public void setPlayerPosition(String playerPosition) {
		PlayerPosition = playerPosition;
	}

	public String getDominantHand() {
		return DominantHand;
	}

	public void setDominantHand(String dominantHand) {
		DominantHand = dominantHand;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getContactInfo() {
		return ContactInfo;
	}

	public void setContactInfo(String contactInfo) {
		ContactInfo = contactInfo;
	}

	public String getSponsorName() {
		return SponsorName;
	}

	public void setSponsorName(String sponsorName) {
		SponsorName = sponsorName;
	}

	public String getPlayerStats() {
		return PlayerStats;
	}

	public void setPlayerStats(String playerStats) {
		PlayerStats = playerStats;
	}
	
	
	
}
