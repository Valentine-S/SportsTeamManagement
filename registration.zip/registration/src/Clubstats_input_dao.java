import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Clubstats_input_dao {
	private String dburl = "jdbc:mysql://localhost:3306/demodb";
	private String dbuname = "root";
	private String dbpassword = "";
	private String dbdriver = "com.mysql.jdbc.Driver";

	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dburl, dbuname, dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public String insert(Clubstats clubstats) {
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into Clubstats values(?,?,?,?,?)";
		String result="Data Entered Successfully";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, clubstats.getStatID());
			ps.setString(2, clubstats.getStatistic());
			ps.setString(3, clubstats.getStatType());
			ps.setString(4, clubstats.getPlayer());
			ps.setNString(5, clubstats.getSeason());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			result="Clubstats are Not Entered Successfully";
			e.printStackTrace();
		}
		return result;

	}
}
