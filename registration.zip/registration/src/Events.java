
public class Events 
{
	private String title,type,details,date;

	public Events() {
		super();
	}
	
	

	public Events(String title, String type, String details, String date) {
		super();
		this.title = title;
		this.type = type;
		this.details = details;
		this.date = date;
	}



	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
}
